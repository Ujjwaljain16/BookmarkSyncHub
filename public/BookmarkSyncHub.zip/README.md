# BookmarkSyncHub Chrome Extension

A powerful Chrome extension to sync and manage your bookmarks with AI-powered features.

## Installation Instructions

1. Download the `BookmarkSyncHub.zip` file
2. Extract the zip file to a folder on your computer
3. Open Chrome and go to `chrome://extensions/`
4. Enable "Developer mode" in the top right corner
5. Click "Load unpacked" and select the extracted folder
6. The extension should now be installed and ready to use!

## Features

- Sync bookmarks with BookmarkHub
- AI-powered bookmark categorization
- Automatic bookmark syncing
- Context menu integration
- Import existing bookmarks
- Customizable settings

## Settings

The extension will automatically connect to the BookmarkHub server. If you need to use a different server:

1. Click the extension icon
2. Click the settings link
3. Enter your custom API URL
4. Click Save

## Support

If you encounter any issues or have questions, please visit our support page at [bookmarkhub.onrender.com](https://bookmarkhub.onrender.com). 